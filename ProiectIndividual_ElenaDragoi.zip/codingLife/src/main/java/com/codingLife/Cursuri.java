package com.codingLife;

public class Cursuri {
    private Long id;
    private String numeCurs;
    private String descriere;
    private double pret;

    
    public Cursuri() {}

    public Cursuri(Long id, String nume, String descriere, double pret) {
        this.id = id;
        this.numeCurs = nume;
        this.descriere = descriere;
        this.pret = pret;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNume() {
        return numeCurs;
    }

    public void setNume(String nume) {
        this.numeCurs = nume;
    }

    public String getDescriere() {
        return descriere;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public double getPret() {
        return pret;
    }

    public void setPret(double pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "Serviciu{" +
                "id=" + id +
                ", nume='" + numeCurs + '\'' +
                ", pret=" + pret +
                '}';
    }
}
