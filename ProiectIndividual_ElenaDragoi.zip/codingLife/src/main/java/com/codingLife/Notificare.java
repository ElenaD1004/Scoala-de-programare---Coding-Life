package com.codingLife;

public class Notificare {
    private Long id;
    private String titlu;
    private String mesaj;
    private Long userId; // Utilizatorul care primește notificarea

   
    public Notificare() {}

    public Notificare(Long id, String titlu, String mesaj, Long userId) {
        this.id = id;
        this.titlu = titlu;
        this.mesaj = mesaj;
        this.userId = userId;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitlu() {
        return titlu;
    }

    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

    public String getMesaj() {
        return mesaj;
    }

    public void setMesaj(String mesaj) {
        this.mesaj = mesaj;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

   
    @Override
    public String toString() {
        return "Notificare{" +
                "id=" + id +
                ", titlu='" + titlu + '\'' +
                ", mesaj='" + mesaj + '\'' +
                ", userId=" + userId +
                '}';
    }
}
