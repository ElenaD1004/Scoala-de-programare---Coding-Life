package com.codingLife;

public class Abonament {
    private Long id;
    private String tip; // ex: ,,Program 1:1"; ,,Clasa 5 elevi"
    private double pret;
    private int durataLuni; // Durata abonamentului 

    
    public Abonament() {}

    public Abonament(Long id, String tip, double pret, int durataLuni) {
        this.id = id;
        this.tip = tip;
        this.pret = pret;
        this.durataLuni = durataLuni;
    }

  
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public double getPret() {
        return pret;
    }

    public void setPret(double pret) {
        this.pret = pret;
    }

    public int getDurataLuni() {
        return durataLuni;
    }

    public void setDurataLuni(int durataLuni) {
        this.durataLuni = durataLuni;
    }


    @Override
    public String toString() {
        return "Abonament{" +
                "id=" + id +
                ", tip='" + tip + '\'' +
                ", pret=" + pret +
                ", durataLuni=" + durataLuni +
                '}';
    }
}
