package com.codingLife;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingLifeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingLifeApplication.class, args);
	}

}
