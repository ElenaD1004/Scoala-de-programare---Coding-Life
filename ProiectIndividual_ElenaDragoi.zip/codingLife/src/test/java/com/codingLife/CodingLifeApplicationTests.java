package com.codingLife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingLifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
